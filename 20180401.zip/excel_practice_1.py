from openpyxl import Workbook
from openpyxl import load_workbook

wb = Workbook()
ws = wb.active
ws.title = "sample 1"
ws1 = wb.create_sheet("sheet_1")


for i in range(1, 11):
    for j in range(1, 11):
        ws.cell(row=i, column=j, value=(i - 1) * 10 + j)

for col_c in ws["C"]:
    print(col_c.value)

print("-" * 20)

print(ws["A:C"])

for data in ws["A:C"]:
    for cell in data:
        print(cell.value)
    print("-" * 20)

print("=" * 20)

for row in ws.iter_rows():
    print(row[2].value, row[4].value)
    print("-" * 20)

loaded_wb = load_workbook("matrix.xlsx")
loaded_ws = loaded_wb.get_sheet_by_name("sample 1")
print(loaded_ws["A1"].value)

        
