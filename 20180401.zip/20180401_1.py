class ScoreError(Exception):
    def __str__(self):
        return "점수는 100점을 넘을 수 없습니다."

def input_score(score):
    if score > 100:
        raise ScoreError()

try:
    input_score(101)
except ScoreError as e:
    print(e)
    print("뭔가 문제가 있다.")
