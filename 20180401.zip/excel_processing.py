from openpyxl import Workbook

wb = Workbook()
ws = wb.active
ws.title = "sample 1"
ws1 = wb.create_sheet("sheet_1")

ws["A1"] = 10
ws.cell(row=2, column=1, value=20)
print(ws["A1"].value)

wb.save("sample.xlsx")





