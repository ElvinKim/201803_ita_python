import requests
from bs4 import BeautifulSoup



restaurant_list = ["west", "fclt", "east1"]

for r in restaurant_list:
    # HTTP GET Request
    req = requests.get('https://www.kaist.ac.kr/_prog/fodlst/index.php?site_dvs_cd=kr&menu_dvs_cd=050303&dvs_cd={}&stt_dt=2018-03-30&site_dvs='.format(r))
    req.raise_for_status()
    req.encoding = None
    # HTML 소스 가져오기
    html = req.text

    soup = BeautifulSoup(html, "html.parser")
    menu_list = soup.find("table", {"class": "menuTb"}).find_all("td")

    print("{:=^20}".format(r))    
    for menu in menu_list:
        print(menu.text)
        print("-" * 20)
    print("")
