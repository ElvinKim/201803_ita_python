from package import *


module1.sample_a()