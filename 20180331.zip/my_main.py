# import my_statistics

# print(my_statistics.a)
# print(my_statistics.add(10, 20))
from my_statistics import *

print("my_main __name__ : ", __name__)

def sample():
    print("B")



