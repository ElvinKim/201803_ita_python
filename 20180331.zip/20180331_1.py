# 매개변수 초기값
def add(a, b=10):
    return a + b


def login(email, password, remember_me=False):
    print("email : " + email)
    print("password : " + password)

    if remember_me:
        print("email과 password를 기억합니다.")

print(add(10, 20))
print(add(10))

login("sangmook", "1234", True)

# 함수의 효력 범위
print("-" * 20)

n = 0

def make_10():
    global n
    n = 10
    print("inner : ", n)
    return n

make_10()
print("outer : ", n)






