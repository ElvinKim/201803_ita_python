print("{:=^20}".format(" 클래스 "))

class Student:
    student_id = "20171111"
    major = "KSE"
    name = "영희"

    def take_course(self, course):
        print(course, "수업 듣자")

    def study(self, course):
        print(course, "공부 하자")

    def do_hobby(self, hobby):
        print(hobby, "를 하자")


class Car:
    cc = 100
    model = "쌍용 - 티볼리"
    year = "2018"
    category = "SUV"

    def move(self):
        print("오빠 달려")

    def music(self):
        print("노래 뿜뿜")

class Knight:
    level = 20
    name = "만년동기사"
    hp = 200

    def move(self, direction):
        print(direction + "방향으로 이동합니다.")

    def attack(self):
        print(self.name + "이/가 공격합니다.")

    def sample(self):
        print(id(self))





k = Knight()
print(k.name)
print(k.level)
print(k.hp)
k.attack()
k.move("앞")
print(id(k))

print(Knight.__dict__)
print("-" * 20)
print(k.__dict__)
print(k.name)
k.level = 200
print(k.__dict__)
print(k.level)

class Wizard:
    def __init__(self, level, name, hp):
        self.level = level
        self.name = name
        self.hp = hp

    def move(self, direction):
        print(direction + "방향으로 이동합니다.")

    def attack(self):
        print(self.name + "이/가 공격합니다.")

    def set_level(self, level):
        if level > 999:
            self.level = 999
        else:
            self.level = level

    def get_level(self):
        return self.level

    def set_name(self, name):
        self.name = name

    def get_name(self):
        return self.name
w = Wizard(200, "만년동해리포터", 1000)

w.set_level(1000)
print(w.get_level())

w.set_name("만년동 이은결")
print(w.get_name())


print("-" * 20)
class A:
    x = 10

    def func_a(self):
        print("A")

class C:
    x = 20

    def func_a(self):
        print("C")

class B(C, A):
    y = 20


b = B()

print(b.x)
b.func_a()

