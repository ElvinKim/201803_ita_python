# problem 1-1
for i in range(5):
    print("{:^9}".format("*" * (2 * i + 1)))

# problem 1-2
for i in range(5):
    for _ in range(5-(i + 1)):
        print(" ", end="")
    for _ in range(2 * i + 1):
        print("*", end="")
    print("")

# problem 2
sample_str = "ABDDADFDASD"
c = "A"
index_lst = []

for i, s in enumerate(sample_str):
    if c == s:
        index_lst.append(i)

# problem 3
# import random
# random_num = random.randint(1, 100)

# total_cnt = 0

# while True:
#     input_num = int(input("input number : "))
#     total_cnt += 1

#     if input_num > random_num:
#         print("사용자 입력값이 더 큽니다.")
#     if input_num < random_num:
#         print("사용자 입력값이 더 작습니다.")
#     else:
#         print("맞췄습니다.")
#         print("total cnt", total_cnt)
#         break

# problem 4
sample_news = """
Seoul (CNN)South Korean musicians will travel to North Korea this weekend for the first time in over a decade, as the two countries prepare for a groundbreaking leaders' summit next month.

K-pop girl band Red Velvet, starlet Seohyun of Girls' Generation, legendary singers Cho Yong-pil and Lee Sun-hee, and rocker Yoon Do-hyun are among those who will travel north of the demilitarized zone (DMZ) for two concerts in Pyongyang.
Some of the delegation played in North Korea in the 1990s and 2000s, before relations broke down and the concerts stopped in 2005.
On Yoon's first visit to the North Korean capital, he told CNN, one of his band members was almost stopped from playing.
"Our guitarist's hair was yellow," the South Korean rock star told CNN. "The North Koreans talked about that hair and said that he could not perform with it ... it wasn't easy from the beginning!"
South Korean girl group Red Velvet are one of the acts traveling to North Korea for a series of concerts. 
South Korean girl group Red Velvet are one of the acts traveling to North Korea for a series of concerts.
Cultural exchange
Yoon is one of South Korea's most famous musicians, selling millions of records with his group YB since they first got together in 1996.
In the early 2000s, his was one of a few South Korean acts which were allowed to perform in the North, even with a yellow-haired guitarist.
Permission did not necessarily mean understanding however, and Yoon said many North Koreans in the crowd did not know what to make of the band's guitar-heavy rock anthems and ballads -- even a rock-and-roll version of the popular pan-Korean folk song "Arirang."
"It was awkward, because they (had) never experienced Korean rock music before," he said. Footage of the concerts, broadcast by South Korean TV station MBC, showed the stiff reactions of the audience.
"(Eventually) they relaxed and enjoyed it," Yoon said. "I felt something difficult being untangled little by little, so I felt very positive."
YB guitarist Heo Joon was almost barred from playing in Pyongyang, North Korea due to his then yellow hair.
YB guitarist Heo Joon was almost barred from playing in Pyongyang, North Korea due to his then yellow hair.
Returning to North Korea this weekend will be an emotional moment for Yoon.
His grandmother, Jang Gyung-ae, was born in Hwanghae Province in what is now North Korea in 1930. "Her family are still in North Korea," Yoon said.
Jang hasn't seen her relatives in decades, and doesn't know if they are alive or dead.
Performing in Pyongyang in 2002, that thought brought Yoon to tears on stage after he saw an older woman in the audience who reminded him of his grandmother.
"Before I went, she asked me, 'can you find my family'?" he said. This week, she asked him again.
"We go as something similar to a cultural mission and do the performance diligently. If that moves North Korean citizens' hearts and the two relationships get a little better through music, I think that's what we can do."
Yoon Do-hyun of YB Band performs during the Pentaport Rock Festival on August 3, 2013 in Incheon, South Korea.
Yoon Do-hyun of YB Band performs during the Pentaport Rock Festival on August 3, 2013 in Incheon, South Korea.
Emotional moment
North and South Korea are still technically at war and their citizens are rarely allowed to cross the heavily fortified DMZ.
The first substantive cultural exchange took place in September 1985.
An art troupe from South Korea traveled to Pyongyang for a four-day visit, and a group from the North made a similar trip south. Families separated by the war joined them. Newsreel from the time shows emotional meetings between relatives.
Exchanges continued until the early 2000s, when relations broke down and the concerts stopped. When tensions were running high, South Korea blasted K-pop toward the North with giant speakers as part of propaganda broadcasts.
But 2018 has seen a dramatic thaw in tensions and a resumption of inter-Korean concerts.
During the recent Winter Olympics in Pyeongchang, South Korea, the North sent their own art troupe to accompany a delegation of athletes, a cheering squad and officials including leader Kim Jong Un's sister, Kim Yo Jong.
The troupe was led by Hyun Song Wol, a performer in the Moranbong girl band, which was formed by Kim himself in 2012.
Play Video

Who's who in North Korea's Olympic delegation 01:07
South Korea's delegation traveling to Pyongyang this weekend totals some 190 people, including performers, staff and government officials.
They will perform two concerts: one on Sunday, April 1 at the 1,500 capacity East Pyongyang Grand Theater, and a joint concert with North Korean musicians on Tuesday, April 3 at the 12,000 capacity Ryugyong Chung Ju Yong Gymnasium, where each country will put on a 25-minute performance before taking to the stage together for a five-minute act.
Singer Seohyun of South Korean group Girls&#39; Generation performs a song from her first solo album &quot;Don&#39;t Say No&quot; on January 16, 2017 in Seoul, South Korea.
Singer Seohyun of South Korean group Girls' Generation performs a song from her first solo album "Don't Say No" on January 16, 2017 in Seoul, South Korea.
Set lists for the two concerts have yet to be released. But YB told CNN they plan to perform three tracks, including "1178," which Yoon said was an "emotional" song named after the length in kilometers of the Korean Peninsula.
"It's about Korea and unity," he said, adding he has to stop himself from crying when he images playing it in North Korea.
Other band members are equally emotional. Drummer Kim Jin-won, whose family lives in Sokcho, 35 km (22 miles) from the DMZ, said that "when we pull out our passports, we're not foreigners, but we're also not from North Korea."
"Even if the unification does not happen soon, I hope this becomes the opportunity for opening civilian exchanges and tours, doing business together and reuniting separated families," he said.
"I hope that our performance becomes a stepping stone."
"""

word_dict = {}
for word in sample_news.split():
    if not word_dict.get(word):
        word_dict[word] = 1
    else:
        word_dict[word] += 1

for word, cnt in word_dict.items():
    print(word, cnt)












