import sys

A = 10
B = 20


def add(x, y):
    return x + y

def sample():
    print("A")

print("my_statistics __name__ : ", __name__)

if __name__ == "__main__":
    print(add(10, 20))
    print("AAAAA")