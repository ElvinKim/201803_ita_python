def sample_a():
    print("module1")