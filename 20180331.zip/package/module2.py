def sample_b():
    print("module2")
