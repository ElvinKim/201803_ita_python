print("{:=^20}".format(" 예외처리 "))


# while True:
#     try:
#         a = int(input("a = "))
#         b = int(input("b = "))
#         print(a / b)
#     except ZeroDivisionError as e:
#         print(e)
#         print("0으로 나눴어!!")
#     except TypeError as e:
#         print(e)
#         print("int로 바꿔야돼")


class Person:
    def introduce(self):
        raise NotImplemented

class Police(Person):
    def introduce(self):
        print("나는 경찰관이야~")

kim = Police()
kim.introduce()