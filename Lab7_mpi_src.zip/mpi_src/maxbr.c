#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define SERVER 0
#define NUM 2048

int main(int argc, char ** argv) {
	FILE *filePtr;
	int rank, size, data_size, start;
	MPI_Status status;
	int temp, max, gMax, numValues;
	int allValues[NUM];

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&size);

	if (rank == SERVER) {
		int const LINE_LENGTH = 15;
		char charNum[LINE_LENGTH];
		int x;

		filePtr = fopen(argv[1], "r");

		// Find out the number of values and set up variables accordingly
		fgets(charNum, LINE_LENGTH, filePtr);
		numValues = atoi(charNum);

		// Read in values from the file
		for (x = 0; x < numValues; x++) {
			fgets(charNum, LINE_LENGTH, filePtr);
			allValues[x] = atoi(charNum);
		}

		fclose(filePtr);
		data_size = numValues / size;
	}

	MPI_Bcast(&numValues, 1, MPI_INT, SERVER, MPI_COMM_WORLD);
	MPI_Bcast(&data_size, 1, MPI_INT, SERVER, MPI_COMM_WORLD);
	MPI_Bcast(allValues, numValues, MPI_INT, SERVER, MPI_COMM_WORLD);

	// Find the max value in the local array
	start = (rank*data_size);
	max = allValues[rank];
	for (temp = start; temp <= (start + data_size); temp++){
		if(temp > numValues) break;
		if (allValues[temp] > max) max = allValues[temp];
	}

	printf("Process %d - my local maximum is %d\n", rank, max);

	MPI_Reduce(&max,&gMax,1,MPI_INT,MPI_MAX,SERVER,MPI_COMM_WORLD); 

	if (rank == SERVER) {
		printf("The grand max is %d\n", gMax);
	}

	MPI_Finalize();
	return 0;
}
