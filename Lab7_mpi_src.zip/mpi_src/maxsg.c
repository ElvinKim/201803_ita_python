#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define SERVER 0
#define NUM 2048

int main(int argc, char ** argv) {
	FILE *filePtr;
	int rank, size, data_size, start;
	MPI_Status status;
	int temp, max, Maxs[5], numValues, gMax;
	int data_size_array[5];
	int allValues[NUM];
	int localValues[NUM];
	
	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	MPI_Comm_size(MPI_COMM_WORLD,&size);

	if (rank == SERVER) {
		int const LINE_LENGTH = 15;
		char charNum[LINE_LENGTH];
		int x;

		filePtr = fopen(argv[1], "r");

		// Find out the number of values and set up variables accordingly
		fgets(charNum, LINE_LENGTH, filePtr);
		numValues = atoi(charNum);

		// Read in values from the file
		for (x = 0; x < numValues; x++) {
			fgets(charNum, LINE_LENGTH, filePtr);
			allValues[x] = atoi(charNum);
		}

		fclose(filePtr);
		data_size = numValues / size;
		int i;
		for(i = 0; i < size; ++i)
			data_size_array[i] = data_size;
	}
	MPI_Scatter(data_size_array, 1, MPI_INT, &data_size, 1, MPI_INT, SERVER, MPI_COMM_WORLD);
	MPI_Scatter(allValues, data_size, MPI_INT, localValues, data_size, MPI_INT, SERVER, MPI_COMM_WORLD);

	// Find the max value in the local array
	max = localValues[0];
	for (temp = 0; temp < data_size; temp++){
		if (localValues[temp] > max) max = localValues[temp];
	}

	printf("Process %d - my local maximum is %d\n", rank, max);

	MPI_Gather(&max, 1, MPI_INT, &Maxs, 1, MPI_INT, SERVER, MPI_COMM_WORLD); 

	if (rank == SERVER) {
		gMax = Maxs[0];
		int i;
		for(i  = 0; i < size; ++i)
		{
			if(Maxs[i] > gMax)
				gMax = Maxs[i];
		}
		printf("The grand max is %d\n", gMax);
	}

	MPI_Finalize();
	return 0;
}
