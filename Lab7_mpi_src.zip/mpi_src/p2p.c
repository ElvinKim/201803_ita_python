#include <stdio.h>
#include <stdlib.h>
#include "mpi.h"

void main (int argc, char **argv)
{
	int myproc, size, other_proc, nprocs, i, last;
	double t0, t1, time;
	double *a, *b;
	double max_rate = 0.0, min_latency = 10e6;
	int    namelen;
	char   hostname[50];

	MPI_Request request, request_a, request_b;
	MPI_Status status;

	a = (double *) malloc (132000 * sizeof (double));
	b = (double *) malloc (132000 * sizeof (double));

	for (i = 0; i < 132000; i++) {
		a[i] = (double) i;
		b[i] = 0.0;
	}

	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &nprocs);
	MPI_Comm_rank(MPI_COMM_WORLD, &myproc);
	MPI_Get_processor_name(hostname,&namelen);


	if (nprocs != 2) exit (1);
	other_proc = (myproc + 1) % 2;

	printf("Hello from %d(%s) of %d\n", myproc, hostname, nprocs);
	MPI_Barrier(MPI_COMM_WORLD);

	/* Timer accuracy test */

	t0 = MPI_Wtime();
	t1 = MPI_Wtime();
	printf("t0=%f and t1=%f\n", t0,t1);
	while (t1 == t0){
		t1 = MPI_Wtime();
	}

	if (myproc == 0)
		printf("Timer accuracy of ~%f usecs\n\n", (t1 - t0) * 1000000);

	/* Communications between nodes 
	 *   - Blocking sends and recvs
	 */
	MPI_Barrier(MPI_COMM_WORLD);
	if (myproc == 0) printf("\n  blocking send\n\n");


	for (size = 8; size <= 1048576; size *= 2) {
		for (i = 0; i < size / 8; i++) {
			a[i] = (double) i;
			b[i] = 0.0;
		}
		last = size / 8 - 1;

		MPI_Barrier(MPI_COMM_WORLD);
		t0 = MPI_Wtime();

		if (myproc == 0) {

			MPI_Send(a, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD);
			MPI_Recv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &status);

		} else {

			MPI_Recv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &status);

			b[0] += 1.0;
			if (last != 0)
				b[last] += 1.0;

			MPI_Send(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD);

		}

		t1 = MPI_Wtime();
		time = 1.e6 * (t1 - t0);
		MPI_Barrier(MPI_COMM_WORLD);

		if ((b[0] != 1.0 || b[last] != last + 1)) {
			printf("ERROR - b[0] = %f b[%d] = %f\n", b[0], last, b[last]);
			exit (1);
		}
		for (i = 1; i < last - 1; i++)
			if (b[i] != (double) i)
				printf("ERROR - b[%d] = %f\n", i, b[i]);
		if (myproc == 0 && time > 0.000001) {
			printf(" %7d bytes took %9.0f usec (%8.3f MB/sec)\n",
					size, time, 2.0 * size / time);
			if (2 * size / time > max_rate) max_rate = 2 * size / time;
			if (time / 2 < min_latency) min_latency = time / 2;
		} else if (myproc == 0) {
			printf(" %7d bytes took less than the timer accuracy\n", size);
		}
	}

	/* (1) Modify above blocking sends to Blocking synchronous sends  */
	MPI_Barrier(MPI_COMM_WORLD);
	if (myproc == 0) printf("\n  blocking synchronous send\n\n");

	for (size = 8; size <= 1048576; size *= 2) {
		for (i = 0; i < size / 8; i++) {
			a[i] = (double) i;
			b[i] = 0.0;
		}
		last = size / 8 - 1;

		MPI_Barrier(MPI_COMM_WORLD);
		t0 = MPI_Wtime();

		if (myproc == 0) {

			MPI_Ssend(a, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD);
			MPI_Recv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &status);

		} else {

			MPI_Recv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &status);

			b[0] += 1.0;
			if (last != 0)
				b[last] += 1.0;

			MPI_Ssend(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD);

		}

		t1 = MPI_Wtime();
		time = 1.e6 * (t1 - t0);
		MPI_Barrier(MPI_COMM_WORLD);

		if ((b[0] != 1.0 || b[last] != last + 1)) {
			printf("ERROR - b[0] = %f b[%d] = %f\n", b[0], last, b[last]);
			exit (1);
		}
		for (i = 1; i < last - 1; i++)
			if (b[i] != (double) i)
				printf("ERROR - b[%d] = %f\n", i, b[i]);
		if (myproc == 0 && time > 0.000001) {
			printf(" %7d bytes took %9.0f usec (%8.3f MB/sec)\n",
					size, time, 2.0 * size / time);
			if (2 * size / time > max_rate) max_rate = 2 * size / time;
			if (time / 2 < min_latency) min_latency = time / 2;
		} else if (myproc == 0) {
			printf(" %7d bytes took less than the timer accuracy\n", size);
		}
	}

	/* (2) Modify above blocking sends to Nonblocking sends  */
	MPI_Barrier(MPI_COMM_WORLD);
	if (myproc == 0) printf("\n  nonblocking send\n\n");

	for (size = 8; size <= 1048576; size *= 2) {
		for (i = 0; i < size / 8; i++) {
			a[i] = (double) i;
			b[i] = 0.0;
		}
		last = size / 8 - 1;

		MPI_Barrier(MPI_COMM_WORLD);
		t0 = MPI_Wtime();

		if (myproc == 0) {

			MPI_Isend(a, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &request);
			MPI_Recv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &status);
		} else {

			MPI_Recv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &status);

			b[0] += 1.0;
			if (last != 0)
				b[last] += 1.0;

			MPI_Isend(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &request);
		}
		MPI_Wait(&request, &status);

		t1 = MPI_Wtime();
		time = 1.e6 * (t1 - t0);
		MPI_Barrier(MPI_COMM_WORLD);

		if ((b[0] != 1.0 || b[last] != last + 1)) {
			printf("ERROR - b[0] = %f b[%d] = %f\n", b[0], last, b[last]);
			exit (1);
		}
		for (i = 1; i < last - 1; i++)
			if (b[i] != (double) i)
				printf("ERROR - b[%d] = %f\n", i, b[i]);
		if (myproc == 0 && time > 0.000001) {
			printf(" %7d bytes took %9.0f usec (%8.3f MB/sec)\n",
					size, time, 2.0 * size / time);
			if (2 * size / time > max_rate) max_rate = 2 * size / time;
			if (time / 2 < min_latency) min_latency = time / 2;
		} else if (myproc == 0) {
			printf(" %7d bytes took less than the timer accuracy\n", size);
		}
	}
	/* (3) Modify above blocking sends to Nonblocking recv  */
	MPI_Barrier(MPI_COMM_WORLD);
	if (myproc == 0) printf("\n  non blocking recv\n\n");

	for (size = 8; size <= 1048576; size *= 2) {
		for (i = 0; i < size / 8; i++) {
			a[i] = (double) i;
			b[i] = 0.0;
		}
		last = size / 8 - 1;

		MPI_Barrier(MPI_COMM_WORLD);
		t0 = MPI_Wtime();

		if (myproc == 0) {
			MPI_Send(a, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD);
			MPI_Irecv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &request);
			MPI_Wait(&request, &status);
		} else {
			MPI_Irecv(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD, &request);
			MPI_Wait(&request, &status);

			b[0] += 1.0;
			if (last != 0)
				b[last] += 1.0;

			MPI_Send(b, size/8, MPI_DOUBLE, other_proc, 0, MPI_COMM_WORLD);
		}

		t1 = MPI_Wtime();
		time = 1.e6 * (t1 - t0);
		MPI_Barrier(MPI_COMM_WORLD);

		if ((b[0] != 1.0 || b[last] != last + 1)) {
			printf("ERROR - b[0] = %f b[%d] = %f\n", b[0], last, b[last]);
			exit (1);
		}
		for (i = 1; i < last - 1; i++)
			if (b[i] != (double) i)
				printf("ERROR - b[%d] = %f\n", i, b[i]);
		if (myproc == 0 && time > 0.000001) {
			printf(" %7d bytes took %9.0f usec (%8.3f MB/sec)\n",
					size, time, 2.0 * size / time);
			if (2 * size / time > max_rate) max_rate = 2 * size / time;
			if (time / 2 < min_latency) min_latency = time / 2;
		} else if (myproc == 0) {
			printf(" %7d bytes took less than the timer accuracy\n", size);
		}
	}
	MPI_Finalize();
}
